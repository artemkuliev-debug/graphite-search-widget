package com.graphitemono.coveragescanner;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int SAVE_JSON = 2401;
    private TextView status;
    private Button saveButton;
    private String reportJson = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        scan();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(28), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(16,17,20));

        TextView title = new TextView(this);
        title.setText("Graphite Coverage Scanner");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setTypeface(null, 1);
        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView intro = new TextView(this);
        intro.setText("Сканирует приложения, которые видит лаунчер, и сохраняет точные package/activity. Никаких личных данных, файлов или содержимого приложений.");
        intro.setTextColor(Color.LTGRAY);
        intro.setTextSize(15);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ip.topMargin = dp(12);
        root.addView(intro, ip);

        Button scanButton = new Button(this);
        scanButton.setText("СКАНИРОВАТЬ ЗАНОВО");
        scanButton.setOnClickListener(v -> scan());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
        bp.topMargin = dp(24);
        root.addView(scanButton, bp);

        saveButton = new Button(this);
        saveButton.setText("СОХРАНИТЬ JSON");
        saveButton.setEnabled(false);
        saveButton.setOnClickListener(v -> saveJson());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
        sp.topMargin = dp(10);
        root.addView(saveButton, sp);

        ScrollView scroll = new ScrollView(this);
        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(14);
        status.setPadding(0, dp(18), 0, dp(20));
        scroll.addView(status);
        LinearLayout.LayoutParams scp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        root.addView(scroll, scp);

        setContentView(root);
    }

    private void scan() {
        try {
            PackageManager pm = getPackageManager();
            Intent launcherIntent = new Intent(Intent.ACTION_MAIN, null);
            launcherIntent.addCategory(Intent.CATEGORY_LAUNCHER);

            List<ResolveInfo> resolved;
            if (Build.VERSION.SDK_INT >= 33) {
                resolved = pm.queryIntentActivities(launcherIntent, PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL));
            } else {
                resolved = pm.queryIntentActivities(launcherIntent, PackageManager.MATCH_ALL);
            }

            Collections.sort(resolved, Comparator.comparing(r -> String.valueOf(r.loadLabel(pm)).toLowerCase(Locale.ROOT)));

            JSONArray activities = new JSONArray();
            Set<String> packages = new HashSet<>();
            StringBuilder preview = new StringBuilder();

            for (ResolveInfo r : resolved) {
                if (r.activityInfo == null) continue;
                String pkg = r.activityInfo.packageName;
                String activity = r.activityInfo.name;
                String label = String.valueOf(r.loadLabel(pm));
                packages.add(pkg);

                JSONObject item = new JSONObject();
                item.put("label", label);
                item.put("package", pkg);
                item.put("activity", activity);
                item.put("component", pkg + "/" + activity);
                try {
                    PackageInfo pi;
                    if (Build.VERSION.SDK_INT >= 33) {
                        pi = pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0));
                    } else {
                        pi = pm.getPackageInfo(pkg, 0);
                    }
                    item.put("versionName", pi.versionName == null ? "" : pi.versionName);
                    item.put("versionCode", Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode);
                } catch (Exception ignored) {}
                activities.put(item);

                if (preview.length() < 12000) {
                    preview.append(label).append("\n  ").append(pkg).append("\n  ").append(activity).append("\n\n");
                }
            }

            JSONObject root = new JSONObject();
            root.put("schema", "graphite-coverage-v1");
            root.put("generatedAt", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(new Date()));
            root.put("androidSdk", Build.VERSION.SDK_INT);
            root.put("device", Build.MANUFACTURER + " " + Build.MODEL);
            root.put("packageCount", packages.size());
            root.put("launcherActivityCount", activities.length());
            root.put("apps", activities);
            reportJson = root.toString(2);

            status.setText("ГОТОВО\n\nПриложений: " + packages.size() + "\nLauncher activities: " + activities.length() +
                    "\n\nНажми «СОХРАНИТЬ JSON» и отправь получившийся файл в ChatGPT.\n\n--- ПРЕДПРОСМОТР ---\n\n" + preview);
            saveButton.setEnabled(true);
        } catch (Exception e) {
            status.setText("Ошибка сканирования:\n" + e.toString());
            saveButton.setEnabled(false);
        }
    }

    private void saveJson() {
        if (reportJson.isEmpty()) return;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, "graphite-phone-coverage.json");
        startActivityForResult(i, SAVE_JSON);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != SAVE_JSON || resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
            if (out == null) throw new IllegalStateException("Cannot open output");
            out.write(reportJson.getBytes(StandardCharsets.UTF_8));
            out.flush();
            Toast.makeText(this, "JSON сохранён. Отправь его в ChatGPT.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось сохранить: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
