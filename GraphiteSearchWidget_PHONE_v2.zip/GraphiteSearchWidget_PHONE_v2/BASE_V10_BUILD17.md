# Graphite Mono Base v10 / build 17

Catalog: 360 app packages.
Appfilter exact/candidate component entries: 1219.
Icon drawables in catalog: 361.

## What changed
- Mass-market catalog instead of phone-specific pack.
- New monochrome Graphite fallback/monogram icons for catalog apps without bespoke artwork.
- Device coverage scanner distinguishes exact mapping / mapping needed / icon needed.
- Share-based missing-icon request; no server required.
- Fallback iconback/iconmask/iconupon for unknown apps.
- Existing bespoke Graphite icons preserved for the original supported apps.

## Categories
- AI: 5
- Books: 3
- Browser: 7
- Cloud: 5
- Crypto: 8
- Custom: 10
- Design: 1
- Dev: 3
- Finance: 22
- Fitness: 8
- Food: 10
- Games: 19
- Google: 44
- Health: 6
- Launcher: 8
- Media: 27
- Microsoft: 20
- Photo: 8
- Productivity: 8
- Samsung: 42
- Security: 9
- Shopping: 17
- Social: 30
- Travel: 17
- Utility: 15
- Video: 3
- Weather: 5
