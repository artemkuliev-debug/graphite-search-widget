# Graphite Mono Base 21

Pastello/CandyBar compatibility pass.

- Added direct Smart Launcher apply action: `ginlemon.smartlauncher.setGSLTHEME` with `package=com.graphitemono.cleanpack`.
- Smart Launcher manifest discovery now matches production packs: `ginlemon.smartlauncher.THEMES` only (removed legacy BUBBLESTYLE/BUBBLEICONS from the same filter).
- Preserved 453-app catalog and 1617 component mappings from Base 20.
- This build is intended to test global application behavior, not mapping coverage.
