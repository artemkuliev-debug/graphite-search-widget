import java.io.*;
import java.net.*;
import java.net.http.*;
import java.nio.file.*;
import java.util.zip.*;

public class GradleBootstrap {
  public static void main(String[] args) throws Exception {
    String version = args[0];
    Path boot = Paths.get(args[1]);
    Files.createDirectories(boot);
    Path zip = boot.resolve("gradle-" + version + "-bin.zip");
    URI uri = URI.create("https://services.gradle.org/distributions/gradle-" + version + "-bin.zip");

    if (!Files.exists(zip)) {
      System.out.println("Downloading Gradle " + version + " (first build only)...");
      HttpClient client = HttpClient.newBuilder()
          .followRedirects(HttpClient.Redirect.ALWAYS)
          .build();
      HttpRequest req = HttpRequest.newBuilder(uri).GET().build();
      HttpResponse<Path> resp = client.send(req, HttpResponse.BodyHandlers.ofFile(zip));
      if (resp.statusCode() < 200 || resp.statusCode() >= 300) {
        throw new IOException("Gradle download failed, HTTP " + resp.statusCode());
      }
    }

    Path marker = boot.resolve("gradle-" + version).resolve("bin").resolve("gradle");
    if (!Files.exists(marker)) {
      System.out.println("Unpacking Gradle " + version + "...");
      try (ZipInputStream zis = new ZipInputStream(Files.newInputStream(zip))) {
        ZipEntry e;
        while ((e = zis.getNextEntry()) != null) {
          Path out = boot.resolve(e.getName()).normalize();
          if (!out.startsWith(boot)) throw new IOException("Bad zip entry: " + e.getName());
          if (e.isDirectory()) {
            Files.createDirectories(out);
          } else {
            Files.createDirectories(out.getParent());
            Files.copy(zis, out, StandardCopyOption.REPLACE_EXISTING);
          }
          zis.closeEntry();
        }
      }
    }
  }
}
