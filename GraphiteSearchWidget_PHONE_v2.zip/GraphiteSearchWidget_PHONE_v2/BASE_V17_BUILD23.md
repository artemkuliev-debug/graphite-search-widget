# Graphite Mono Base 23

Smart Launcher cache-bust test. The 20 redesigned icons from Base 22 now use entirely new Android drawable resource names (`ic_g23_*`). All exact references in appfilter/theme/drawable catalogs were updated. Artwork and component mappings are unchanged from Base 22.
