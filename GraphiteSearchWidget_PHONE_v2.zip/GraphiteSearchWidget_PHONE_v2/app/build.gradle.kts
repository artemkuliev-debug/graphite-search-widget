plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.graphitemono.cleanpack"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.graphitemono.cleanpack.test26"
        minSdk = 26
        targetSdk = 36
        versionCode = 26
        versionName = "1.0-base26-brand-pass"
    }

    signingConfigs {
        create("graphiteDev") {
            storeFile = file("graphite-dev.jks")
            storePassword = "graphite-dev"
            keyAlias = "graphite"
            keyPassword = "graphite-dev"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("graphiteDev")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    jvmToolchain(17)
}
