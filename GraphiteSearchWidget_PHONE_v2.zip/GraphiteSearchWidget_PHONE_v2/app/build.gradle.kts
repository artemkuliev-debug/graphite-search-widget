plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.graphite.searchwidget"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.graphite.searchwidget"
        minSdk = 26
        targetSdk = 36
        versionCode = 2
        versionName = "0.2-graphite-pack"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    jvmToolchain(17)
}
