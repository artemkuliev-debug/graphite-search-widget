plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.graphite.searchwidget"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.graphite.searchwidget"
        minSdk = 26
        targetSdk = 36
        versionCode = 8
        versionName = "0.8-dev"
    }

    signingConfigs {
        create("graphiteDev") {
            storeFile = file("graphite-dev.jks")
            storePassword = "graphite-dev"
            keyAlias = "graphite"
            keyPassword = "graphite-dev"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("graphiteDev")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    jvmToolchain(17)
}
