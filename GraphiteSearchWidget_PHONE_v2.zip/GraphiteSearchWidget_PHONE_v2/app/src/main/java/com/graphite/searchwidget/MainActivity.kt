package com.graphite.searchwidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.util.Xml
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.xmlpull.v1.XmlPullParser

class MainActivity : Activity() {
    private lateinit var scanResult: TextView
    private var mappedXml: String = ""
    private var allComponents: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 56, 48, 56)
            setBackgroundColor(Color.rgb(12, 12, 12))
        }

        val title = TextView(this).apply {
            text = "GRAPHITE MONO"
            setTextColor(Color.WHITE)
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
        }

        val subtitle = TextView(this).apply {
            text = "Clock + Search + icon pack\n\nDiagnostic v5: scan the exact launcher components on this phone."
            setTextColor(Color.LTGRAY)
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 30)
        }

        val addClock = actionButton("Добавить часы") {
            pinWidget(ClockWidgetProvider::class.java)
        }

        val addSearch = actionButton("Добавить поиск") {
            pinWidget(SearchWidgetProvider::class.java)
        }

        val scanApps = actionButton("SCAN APPS — package/activity") {
            scanLauncherApps()
        }

        val copyMapped = actionButton("COPY MAPPED XML") {
            if (mappedXml.isBlank()) {
                toast("Сначала нажми SCAN APPS")
            } else {
                copyToClipboard("Graphite mapped appfilter", mappedXml)
            }
        }

        val copyAll = actionButton("COPY ALL COMPONENTS") {
            if (allComponents.isBlank()) {
                toast("Сначала нажми SCAN APPS")
            } else {
                copyToClipboard("Graphite launcher components", allComponents)
            }
        }

        scanResult = TextView(this).apply {
            text = "После SCAN APPS здесь появится точный список launcher components.\n\nMAPPED = уже есть наша Graphite-иконка.\nUNMAPPED = приложение найдено, но иконку ещё нужно добавить."
            setTextColor(Color.rgb(210, 210, 210))
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(0, 28, 0, 40)
        }

        root.addView(title, fullWrap())
        root.addView(subtitle, fullWrap())
        root.addView(addClock, fullWrap())
        root.addView(addSearch, fullWrap(top = 14))
        root.addView(scanApps, fullWrap(top = 30))
        root.addView(copyMapped, fullWrap(top = 14))
        root.addView(copyAll, fullWrap(top = 14))
        root.addView(scanResult, fullWrap())

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(12, 12, 12))
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        setContentView(scroll)
    }

    private fun actionButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun fullWrap(top: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = top }

    private fun scanLauncherApps() {
        val drawableByPackage = readDrawableMapFromAppFilter()
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfos = if (Build.VERSION.SDK_INT >= 33) {
            packageManager.queryIntentActivities(
                intent,
                PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL.toLong())
            )
        } else {
            @Suppress("DEPRECATION")
            packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        }

        val apps = resolveInfos
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { "${it.activityInfo.packageName}/${it.activityInfo.name}" }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }

        val mapped = StringBuilder()
        val all = StringBuilder()
        val preview = StringBuilder()
        var mappedCount = 0

        for (info in apps) {
            val pkg = info.activityInfo.packageName
            val activity = info.activityInfo.name
            val label = info.loadLabel(packageManager).toString().replace("\n", " ")
            val component = "$pkg/$activity"
            val drawable = drawableByPackage[pkg]

            all.append(label).append('\n')
                .append(component).append("\n\n")

            if (drawable != null) {
                mappedCount++
                mapped.append("    <item component=\"ComponentInfo{")
                    .append(xmlEscape(pkg)).append('/').append(xmlEscape(activity))
                    .append("}\" drawable=\"").append(drawable).append("\" />")
                    .append(" <!-- ").append(xmlCommentSafe(label)).append(" -->\n")

                preview.append("✓ ").append(label).append('\n')
                    .append(component).append('\n')
                    .append("→ ").append(drawable).append("\n\n")
            } else {
                preview.append("• UNMAPPED: ").append(label).append('\n')
                    .append(component).append("\n\n")
            }
        }

        mappedXml = buildString {
            append("<!-- Graphite Mono: exact launcher components scanned on device -->\n")
            append("<!-- mapped=").append(mappedCount)
                .append(" total=").append(apps.size).append(" -->\n")
            append(mapped)
        }
        allComponents = buildString {
            append("Graphite Mono launcher scan\n")
            append("Device: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
            append("Android: ").append(Build.VERSION.RELEASE).append(" (SDK ").append(Build.VERSION.SDK_INT).append(")\n")
            append("Total launcher entries: ").append(apps.size).append("\n\n")
            append(all)
        }

        scanResult.text = buildString {
            append("SCAN COMPLETE\n")
            append("Total: ").append(apps.size)
            append("   Mapped: ").append(mappedCount)
            append("   Unmapped: ").append(apps.size - mappedCount)
            append("\n\n")
            append(preview)
        }

        toast("Готово: ${apps.size} приложений, $mappedCount уже сопоставлены")
    }

    private fun readDrawableMapFromAppFilter(): Map<String, String> {
        val result = LinkedHashMap<String, String>()
        try {
            assets.open("appfilter.xml").use { input ->
                val parser = Xml.newPullParser().apply {
                    setInput(input, "UTF-8")
                }
                var event = parser.eventType
                while (event != XmlPullParser.END_DOCUMENT) {
                    if (event == XmlPullParser.START_TAG && parser.name == "item") {
                        val component = parser.getAttributeValue(null, "component") ?: ""
                        val drawable = parser.getAttributeValue(null, "drawable") ?: ""
                        val body = component.substringAfter("ComponentInfo{", "").substringBefore("}")
                        val pkg = body.substringBefore("/", "")
                        if (pkg.isNotBlank() && drawable.isNotBlank() && !result.containsKey(pkg)) {
                            result[pkg] = drawable
                        }
                    }
                    event = parser.next()
                }
            }
        } catch (e: Exception) {
            toast("Не удалось прочитать appfilter: ${e.javaClass.simpleName}")
        }
        return result
    }

    private fun xmlEscape(value: String): String = value
        .replace("&", "&amp;")
        .replace("\"", "&quot;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")

    private fun xmlCommentSafe(value: String): String = value.replace("--", "—")

    private fun copyToClipboard(label: String, text: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
        toast("Скопировано в буфер")
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun pinWidget(clazz: Class<out AppWidgetProvider>) {
        val manager = AppWidgetManager.getInstance(this)
        val provider = ComponentName(this, clazz)
        if (manager.isRequestPinAppWidgetSupported) {
            manager.requestPinAppWidget(provider, null, null)
        } else {
            Toast.makeText(this, "Добавь виджет Graphite Mono через меню виджетов лаунчера", Toast.LENGTH_LONG).show()
        }
    }
}
