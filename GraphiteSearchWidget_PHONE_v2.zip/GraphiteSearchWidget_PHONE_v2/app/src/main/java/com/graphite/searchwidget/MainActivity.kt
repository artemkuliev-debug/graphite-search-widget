package com.graphite.searchwidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 56, 48, 56)
            setBackgroundColor(Color.rgb(12, 12, 12))
        }

        val title = TextView(this).apply {
            text = "GRAPHITE MONO"
            setTextColor(Color.WHITE)
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
        }

        val subtitle = TextView(this).apply {
            text = "Clock + Search + monochrome icon pack\n\nSmart Launcher: Appearance → Icon appearance → Icon pack → Graphite Mono"
            setTextColor(Color.LTGRAY)
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 36)
        }

        val addClock = Button(this).apply {
            text = "Добавить часы"
            isAllCaps = false
            setOnClickListener { pinWidget(ClockWidgetProvider::class.java) }
        }

        val addSearch = Button(this).apply {
            text = "Добавить поиск"
            isAllCaps = false
            setOnClickListener { pinWidget(SearchWidgetProvider::class.java) }
        }

        root.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(subtitle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(addClock, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(addSearch, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 18 })
        setContentView(root)
    }

    private fun pinWidget(clazz: Class<out AppWidgetProvider>) {
        val manager = AppWidgetManager.getInstance(this)
        val provider = ComponentName(this, clazz)
        if (manager.isRequestPinAppWidgetSupported) {
            manager.requestPinAppWidget(provider, null, null)
        } else {
            Toast.makeText(this, "Добавь виджет Graphite Mono через меню виджетов лаунчера", Toast.LENGTH_LONG).show()
        }
    }
}
