package com.graphitemono.iconpack.widgets;

import android.app.PendingIntent;
import android.app.SearchManager;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;
import com.graphitemono.iconpack.R;

public class SearchWidgetProvider extends AppWidgetProvider {
    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        for (int id : appWidgetIds) update(context, manager, id);
    }

    private static void update(Context context, AppWidgetManager manager, int id) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_search_satin);
        PendingIntent search = PendingIntent.getActivity(context, 4101, searchIntent(context), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent voice = PendingIntent.getActivity(context, 4102, voiceIntent(context), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.search_root, search);
        views.setOnClickPendingIntent(R.id.search_icon, search);
        views.setOnClickPendingIntent(R.id.search_label, search);
        views.setOnClickPendingIntent(R.id.search_mic, voice);
        manager.updateAppWidget(id, views);
    }

    private static Intent searchIntent(Context context) {
        Intent i = new Intent(Intent.ACTION_WEB_SEARCH);
        i.putExtra(SearchManager.QUERY, "");
        i.setPackage("com.google.android.googlequicksearchbox");
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (i.resolveActivity(context.getPackageManager()) != null) return i;
        return new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    }

    private static Intent voiceIntent(Context context) {
        Intent i = new Intent("android.intent.action.VOICE_COMMAND");
        i.setPackage("com.google.android.googlequicksearchbox");
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (i.resolveActivity(context.getPackageManager()) != null) return i;
        return searchIntent(context);
    }
}
