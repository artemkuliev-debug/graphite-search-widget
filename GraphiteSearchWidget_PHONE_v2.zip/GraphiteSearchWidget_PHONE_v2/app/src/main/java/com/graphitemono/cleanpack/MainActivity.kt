package com.graphitemono.cleanpack

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.util.Xml
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser

class MainActivity : Activity() {
    private lateinit var coverageText: TextView
    private lateinit var statusText: TextView
    private var requestText: String = ""
    private var exactXml: String = ""

    data class PackIndex(
        val exactComponents: Set<String>,
        val drawableByPackage: Map<String, String>,
        val catalogPackages: Set<String>,
        val catalogCount: Int
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(44))
            setBackgroundColor(Color.rgb(10, 10, 11))
        }

        val eyebrow = TextView(this).apply {
            text = "GRAPHITE / ICON SYSTEM · BASE 24 TEST · CACHE-BUST TEST"
            textSize = 11f
            letterSpacing = 0.18f
            setTextColor(Color.rgb(140, 144, 150))
            typeface = Typeface.DEFAULT_BOLD
        }
        val title = TextView(this).apply {
            text = "Graphite Mono"
            textSize = 34f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), 0, 0)
        }
        val subtitle = TextView(this).apply {
            text = "Base v17 · 453 apps · 20 redesigned icons · fresh resource IDs"
            textSize = 14f
            setTextColor(Color.rgb(175, 178, 183))
            setPadding(0, dp(7), 0, dp(20))
        }

        val statsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = roundedBg(18, Color.rgb(18, 19, 21), Color.rgb(55, 58, 63))
        }
        coverageText = TextView(this).apply {
            text = "Библиотека загружается…"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        statusText = TextView(this).apply {
            text = "Нажми «Проверить мои приложения». Мы покажем точное покрытие на этом телефоне."
            textSize = 13f
            setTextColor(Color.rgb(185, 188, 194))
            setPadding(0, dp(8), 0, 0)
        }
        statsCard.addView(coverageText, fullWrap())
        statsCard.addView(statusText, fullWrap())

        val applySmart = actionButton("Применить в Smart Launcher") { applyToSmartLauncher() }
        val scan = actionButton("Проверить мои приложения") { scanCoverage() }
        val share = actionButton("Отправить недостающие иконки") {
            if (requestText.isBlank()) toast("Сначала запусти проверку") else shareRequest()
        }
        val copy = secondaryButton("Скопировать компоненты для обновления") {
            if (exactXml.isBlank()) toast("Сначала запусти проверку") else copyToClipboard("Graphite component mappings", exactXml)
        }
        val widgetsTitle = sectionLabel("ВИДЖЕТЫ")
        val addSearch = secondaryButton("Добавить Graphite Search") { pinWidget(SearchWidgetProvider::class.java) }
        val addClock = secondaryButton("Добавить Graphite Clock") { pinWidget(ClockWidgetProvider::class.java) }
        val note = TextView(this).apply {
            text = "Если приложение есть в библиотеке, но его launcher activity изменился после обновления — оно попадёт в список «нужен mapping». Это позволяет добавлять поддержку без угадывания и без скриншотов."
            textSize = 12f
            setTextColor(Color.rgb(135, 139, 145))
            setPadding(0, dp(20), 0, 0)
        }

        page.addView(eyebrow, fullWrap())
        page.addView(title, fullWrap())
        page.addView(subtitle, fullWrap())
        page.addView(statsCard, fullWrap())
        page.addView(applySmart, fullWrap(top = 18))
        page.addView(scan, fullWrap(top = 10))
        page.addView(share, fullWrap(top = 10))
        page.addView(copy, fullWrap(top = 10))
        page.addView(widgetsTitle, fullWrap(top = 28))
        page.addView(addSearch, fullWrap(top = 10))
        page.addView(addClock, fullWrap(top = 10))
        page.addView(note, fullWrap())

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(10, 10, 11))
            addView(page, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        setContentView(scroll)
        showLibrarySize()
    }

    private fun applyToSmartLauncher() {
        val launcherPackages = listOf(
            "ginlemon.flowerfree",
            "ginlemon.flowerpro",
            "ginlemon.flowerpro.special"
        )
        val installed = launcherPackages.firstOrNull { pkg ->
            try {
                @Suppress("DEPRECATION")
                packageManager.getPackageInfo(pkg, 0)
                true
            } catch (_: Exception) { false }
        }

        val apply = Intent("ginlemon.smartlauncher.setGSLTHEME").apply {
            putExtra("package", packageName)
            installed?.let { setPackage(it) }
        }
        try {
            startActivity(apply)
            toast("Graphite Mono передан в Smart Launcher")
        } catch (_: Exception) {
            toast("Smart Launcher не принял direct-apply. Выбери Graphite Mono в настройках иконок.")
        }
    }

    private fun showLibrarySize() {
        val idx = loadPackIndex()
        coverageText.text = "${idx.catalogCount}+ приложений"
        statusText.text = "Base 27: Pastello-style brand-vector pilot · real recognizable brand marks normalized into Graphite Mono · Smart Launcher direct apply preserved."
    }

    private fun scanCoverage() {
        val idx = loadPackIndex()
        val launcherIntent = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        val resolveInfos = if (Build.VERSION.SDK_INT >= 33) {
            packageManager.queryIntentActivities(launcherIntent, PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL.toLong()))
        } else {
            @Suppress("DEPRECATION")
            packageManager.queryIntentActivities(launcherIntent, PackageManager.MATCH_ALL)
        }.filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }

        var exact = 0
        var catalogOnly = 0
        var missing = 0
        val request = StringBuilder()
        val mappings = StringBuilder()

        request.append("Graphite Mono icon request\n")
            .append("Device: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
            .append("Android: ").append(Build.VERSION.RELEASE).append(" / SDK ").append(Build.VERSION.SDK_INT).append("\n\n")

        for (info in resolveInfos) {
            val pkg = info.activityInfo.packageName
            val label = info.loadLabel(packageManager).toString().replace("\n", " ")
            val candidates = linkedSetOf<String>()
            info.activityInfo.name?.takeIf { it.isNotBlank() }?.let { candidates.add(it) }
            info.activityInfo.targetActivity?.takeIf { it.isNotBlank() }?.let { candidates.add(it) }
            try { packageManager.getLaunchIntentForPackage(pkg)?.component?.className?.let { candidates.add(it) } } catch (_: Exception) {}

            val exactActivity = candidates.firstOrNull { idx.exactComponents.contains("$pkg/$it") }
            when {
                exactActivity != null -> exact++
                idx.catalogPackages.contains(pkg) -> {
                    catalogOnly++
                    request.append("MAPPING NEEDED | ").append(label).append(" | ").append(pkg).append('\n')
                    for (a in candidates) request.append("  ").append(pkg).append('/').append(a).append('\n')
                }
                else -> {
                    missing++
                    request.append("ICON NEEDED | ").append(label).append(" | ").append(pkg).append('\n')
                    for (a in candidates) request.append("  ").append(pkg).append('/').append(a).append('\n')
                }
            }

            val drawable = idx.drawableByPackage[pkg]
            if (drawable != null) {
                for (a in candidates) {
                    mappings.append("    <item component=\"ComponentInfo{")
                        .append(xmlEscape(pkg)).append('/').append(xmlEscape(a))
                        .append("}\" drawable=\"").append(drawable).append("\" />\n")
                }
            }
        }

        val total = resolveInfos.size.coerceAtLeast(1)
        val coverage = (exact * 100f / total).toInt()
        coverageText.text = "$coverage% mapping coverage"
        statusText.text = "${resolveInfos.size} приложений · $exact готово · $catalogOnly нужен mapping · $missing нужна новая иконка"
        requestText = request.toString()
        exactXml = mappings.toString()
        toast("Проверка готова: $exact из ${resolveInfos.size} exact")
    }

    private fun loadPackIndex(): PackIndex {
        val exact = LinkedHashSet<String>()
        val drawables = LinkedHashMap<String, String>()
        try {
            assets.open("appfilter.xml").use { input ->
                val parser = Xml.newPullParser().apply { setInput(input, "UTF-8") }
                var event = parser.eventType
                while (event != XmlPullParser.END_DOCUMENT) {
                    if (event == XmlPullParser.START_TAG && parser.name == "item") {
                        val component = parser.getAttributeValue(null, "component") ?: ""
                        val drawable = parser.getAttributeValue(null, "drawable") ?: ""
                        val body = component.substringAfter("ComponentInfo{", "").substringBefore("}")
                        val pkg = body.substringBefore("/", "")
                        val act = body.substringAfter("/", "")
                        if (pkg.isNotBlank() && act.isNotBlank()) exact.add("$pkg/$act")
                        if (pkg.isNotBlank() && drawable.isNotBlank() && !drawables.containsKey(pkg)) drawables[pkg] = drawable
                    }
                    event = parser.next()
                }
            }
        } catch (_: Exception) {}

        val catalogPkgs = LinkedHashSet<String>()
        var count = 0
        try {
            val text = assets.open("catalog.json").bufferedReader().use { it.readText() }
            val obj = JSONObject(text)
            val keys = obj.keys()
            while (keys.hasNext()) { catalogPkgs.add(keys.next()); count++ }
        } catch (_: Exception) {}
        return PackIndex(exact, drawables, catalogPkgs, count)
    }

    private fun shareRequest() {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Graphite Mono icon request")
            putExtra(Intent.EXTRA_TEXT, requestText)
        }
        startActivity(Intent.createChooser(send, "Отправить список"))
    }

    private fun sectionLabel(textValue: String) = TextView(this).apply {
        text = textValue
        textSize = 11f
        letterSpacing = 0.16f
        setTextColor(Color.rgb(130, 134, 140))
        typeface = Typeface.DEFAULT_BOLD
    }

    private fun actionButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 15f
        setTextColor(Color.rgb(15, 16, 18))
        background = roundedBg(16, Color.rgb(245, 246, 247), Color.rgb(245, 246, 247))
        minHeight = dp(54)
        setOnClickListener { action() }
    }

    private fun secondaryButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setTextColor(Color.WHITE)
        background = roundedBg(16, Color.rgb(22, 23, 25), Color.rgb(65, 68, 73))
        minHeight = dp(52)
        setOnClickListener { action() }
    }

    private fun roundedBg(radius: Int, fill: Int, stroke: Int) = GradientDrawable().apply {
        cornerRadius = dp(radius).toFloat()
        setColor(fill)
        setStroke(dp(1), stroke)
    }

    private fun fullWrap(top: Int = 0) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun xmlEscape(value: String): String = value.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;").replace(">", "&gt;")
    private fun copyToClipboard(label: String, text: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
        toast("Скопировано")
    }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    private fun pinWidget(clazz: Class<out AppWidgetProvider>) {
        val manager = AppWidgetManager.getInstance(this)
        val provider = ComponentName(this, clazz)
        if (manager.isRequestPinAppWidgetSupported) manager.requestPinAppWidget(provider, null, null)
        else Toast.makeText(this, "Добавь виджет Graphite Mono через меню виджетов лаунчера", Toast.LENGTH_LONG).show()
    }
}
