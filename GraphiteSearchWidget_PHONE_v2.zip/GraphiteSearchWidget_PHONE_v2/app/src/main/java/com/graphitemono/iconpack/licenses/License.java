package com.graphitemono.iconpack.licenses;

public class License {
    private static final boolean ENABLE_LICENSE_CHECKER = false;
    private static final byte[] SALT = new byte[]{};
    private static final String LICENSE_KEY = "";

    public static boolean isLicenseCheckerEnabled() { return ENABLE_LICENSE_CHECKER; }
    public static String getLicenseKey() { return LICENSE_KEY; }
    public static byte[] getRandomString() { return SALT; }
    public static String[] getPremiumRequestProductsId() { return new String[]{}; }
    public static int[] getPremiumRequestProductsCount() { return new int[]{}; }
    public static String[] getDonationProductsId() { return new String[]{}; }
}
