#!/usr/bin/env python3
from pathlib import Path
import re, sys, collections
root=Path(__file__).resolve().parents[1]
main=root/'app/src/main'
appfilter=main/'res/xml/appfilter.xml'
drawable=main/'res/xml/drawable.xml'
drawdir=main/'res/drawable-nodpi'
text=appfilter.read_text(encoding='utf-8')
items=re.findall(r'<item\s+component="ComponentInfo\{([^}]+)\}"\s+drawable="([^"]+)"\s*/>',text)
by=collections.defaultdict(set)
for c,d in items: by[c].add(d)
conf={c:sorted(v) for c,v in by.items() if len(v)>1}
refs={d for _,d in items}
refs.update(re.findall(r'<item\s+drawable="([^"]+)"\s*/>', drawable.read_text(encoding='utf-8')))
existing={p.stem for p in drawdir.iterdir() if p.is_file()}
missing=sorted(refs-existing)
print(f'components={len(by)} mappings={len(items)} drawable_refs={len(refs)}')
print(f'conflicts={len(conf)} missing={len(missing)}')
if conf:
    for k,v in conf.items(): print('CONFLICT',k,v)
if missing:
    for x in missing: print('MISSING',x)
sys.exit(1 if conf or missing else 0)
