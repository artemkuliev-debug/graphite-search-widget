from pathlib import Path
import xml.etree.ElementTree as ET, re, sys
root=Path(__file__).resolve().parents[1]
paths={
 'assets_app':root/'app/src/main/assets/appfilter.xml',
 'res_app':root/'app/src/main/res/xml/appfilter.xml',
 'assets_theme':root/'app/src/main/assets/theme_resources.xml',
 'res_theme':root/'app/src/main/res/xml/theme_resources.xml',
 'assets_drawable':root/'app/src/main/assets/drawable.xml',
 'res_drawable':root/'app/src/main/res/xml/drawable.xml',
 'assets_appmap':root/'app/src/main/assets/appmap.xml',
 'res_appmap':root/'app/src/main/res/xml/appmap.xml',
}
def app(p):
 r=ET.parse(p).getroot(); return {(x.attrib['component'],x.attrib['drawable']) for x in r.findall('item')}
def theme(p):
 r=ET.parse(p).getroot(); return {(x.attrib['name'],x.attrib['image']) for x in r.findall('AppIcon')}
def drawables(p):
 r=ET.parse(p).getroot(); return {x.attrib['drawable'] for x in r.findall('item') if 'drawable' in x.attrib}
def appmap(p):
 r=ET.parse(p).getroot(); return {(x.attrib.get('class'),x.attrib.get('name')) for x in r.findall('item')}
def n(c):
 m=re.fullmatch(r'ComponentInfo\{([^/]+)/(.+)\}',c); return f'{m.group(1)}/{m.group(2)}'
a=app(paths['assets_app']); r=app(paths['res_app']); ta=theme(paths['assets_theme']); tr=theme(paths['res_theme'])
da=drawables(paths['assets_drawable']); dr=drawables(paths['res_drawable'])
ama=appmap(paths['assets_appmap']); amr=appmap(paths['res_appmap'])
expected={(n(c),d) for c,d in a}
used={d for _,d in a}
errors=[]
if a!=r: errors.append(f'appfilter mismatch assets={len(a)} res={len(r)}')
if expected!=ta: errors.append(f'assets theme mismatch expected={len(expected)} actual={len(ta)}')
if expected!=tr: errors.append(f'res theme mismatch expected={len(expected)} actual={len(tr)}')
if da!=dr: errors.append(f'drawable catalog mismatch assets={len(da)} res={len(dr)}')
if not used.issubset(da): errors.append(f'drawable catalog missing {len(used-da)} mapped icons')
if ama!=amr: errors.append(f'appmap mismatch assets={len(ama)} res={len(amr)}')
# verify physical drawable resource exists
resource_dirs=list((root/'app/src/main/res').glob('drawable*'))+list((root/'app/src/main/res').glob('mipmap*'))
physical=set()
for d in resource_dirs:
 if d.is_dir():
  for f in d.iterdir():
   if f.is_file(): physical.add(f.stem)
missing=used-physical
if missing: errors.append(f'physical drawable resources missing {len(missing)}')
if errors:
 print('\n'.join(errors)); sys.exit(1)
print(f'OK: {len(a)} mappings; {len(used)} mapped drawables; launcher catalogs synced')
