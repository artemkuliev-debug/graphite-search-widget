from pathlib import Path
import xml.etree.ElementTree as ET, re, sys
root=Path(__file__).resolve().parents[1]
paths={
 'assets_app':root/'app/src/main/assets/appfilter.xml',
 'res_app':root/'app/src/main/res/xml/appfilter.xml',
 'assets_theme':root/'app/src/main/assets/theme_resources.xml',
 'res_theme':root/'app/src/main/res/xml/theme_resources.xml',
}
def app(p):
 r=ET.parse(p).getroot(); return {(x.attrib['component'],x.attrib['drawable']) for x in r.findall('item')}
def theme(p):
 r=ET.parse(p).getroot(); return {(x.attrib['name'],x.attrib['image']) for x in r.findall('AppIcon')}
def n(c):
 m=re.fullmatch(r'ComponentInfo\{([^/]+)/(.+)\}',c); return f'{m.group(1)}/{m.group(2)}'
a=app(paths['assets_app']); r=app(paths['res_app']); ta=theme(paths['assets_theme']); tr=theme(paths['res_theme'])
expected={(n(c),d) for c,d in a}
errors=[]
if a!=r: errors.append(f'appfilter mismatch assets={len(a)} res={len(r)}')
if expected!=ta: errors.append(f'assets theme mismatch expected={len(expected)} actual={len(ta)}')
if expected!=tr: errors.append(f'res theme mismatch expected={len(expected)} actual={len(tr)}')
if errors:
 print('\n'.join(errors)); sys.exit(1)
print(f'OK: {len(a)} canonical mappings synced across appfilter + theme_resources')
