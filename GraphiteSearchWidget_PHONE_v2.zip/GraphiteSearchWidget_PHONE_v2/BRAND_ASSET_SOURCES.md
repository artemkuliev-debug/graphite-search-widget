# Graphite Mono Base 27 — brand vector pilot

Pilot assets use recognizable one-color brand vector geometry from the Simple Icons project, normalized into the Graphite Mono master tile. The icon-pack artwork itself is exported as Android PNG drawables.

Simple Icons repository: https://github.com/simple-icons/simple-icons

Pilot slugs: shazam, spotify, youtube, telegram, whatsapp, googlephotos, instagram, facebook, steam, netflix, tiktok, pinterest, threads, youtubemusic, pexels

Trademark note: brand names and marks remain the property of their respective owners; commercial release requires the usual brand/trademark review.
