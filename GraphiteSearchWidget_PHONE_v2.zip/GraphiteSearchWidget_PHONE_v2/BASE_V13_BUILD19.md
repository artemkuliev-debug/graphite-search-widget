# Graphite Mono Base 19 / v13

- Catalog: 453 apps
- Added from live Samsung Android 16 request: 93 apps / 104 observed launcher components
- Added generated Graphite live icons: 93
- Canonical component mappings: 1617
- appfilter and theme_resources generated from one mapping set
- Smart Launcher should now see the same mappings as the in-app scanner
