# Graphite Mono Base 18

- versionCode 18 / 1.0-base18
- merged exact launcher component mappings captured on Android 16 / Samsung
- deduplicated against Base 17 appfilter
- corrected Apex/Fede icon-pack discovery filters to avoid extra MAIN entries
- UI label updated to Base v11 / live mappings
- mass catalog remains 360 apps; missing-icon expansion is the next layer
