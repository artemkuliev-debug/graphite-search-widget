# Graphite Mono Base 26

Brand-first visual pass. Replaced priority letter/generic placeholders with recognizable brand or semantic graphite glyphs. Added AllScore mapping candidates. New applicationId test26 avoids Smart Launcher cache from prior builds.
