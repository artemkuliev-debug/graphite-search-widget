Graphite Pack v1

Included:
- Clock widget
- Search widget
- 250 monochrome icon drawables
- ADW/Nova compatible appfilter.xml for common apps
- drawable.xml with all icons for manual picker

This is a test pack. Many non-core icons use original two-letter monochrome monograms; the most visible apps use custom line glyphs.
