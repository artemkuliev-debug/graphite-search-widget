# Graphite Mono production asset pipeline

## Source of truth
- `app/src/main/res/xml/appfilter.xml` — package/activity -> drawable mappings.
- `app/src/main/res/drawable-nodpi/gm26_*.png` — promoted Graphite Satin launcher assets.
- `app/src/main/assets/masters/gm26_*.svg` — vector masters for promoted assets.

## Generated compatibility files
- `app/src/main/assets/appfilter.xml`
- `app/src/main/assets/drawable.xml`
- `app/src/main/res/xml/theme_resources.xml`

Do not edit generated compatibility files independently. `syncIconPackFiles` regenerates them from canonical XML.
`validateIconPack` fails the build when a mapped drawable is missing or the same component maps to conflicting drawables.

## Why this base exists
Older experimental builds accumulated multiple resource names for the same app. That allowed the dashboard preview and launcher mapping to drift apart. The promoted `gm26_*` resources establish one canonical path and also force launchers to resolve the new artwork instead of an old cached drawable name.
