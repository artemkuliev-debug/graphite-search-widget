# Graphite Mono Base 20

Critical launcher compatibility fix:
- `res/xml/drawable.xml` is now synchronized with `assets/drawable.xml`.
- all 93 live icons introduced in Base 19 are present in both launcher drawable catalogs.
- `appmap.xml` generated in both assets and res/xml for broader launcher compatibility.
- build-time verification now checks appfilter, theme_resources, drawable catalogs, appmap and physical drawable resources.
- UI metric renamed from "exact coverage" to "mapping coverage" because internal mapping coverage does not prove a launcher has applied every icon.
